
import { Telegraf, session } from 'telegraf';
import fs from 'fs';
import config from './config.json' assert { type: 'json' };

const bot = new Telegraf(config.BOT_TOKEN);
bot.use(session());

// In-memory storage
const referrals = {};
const userProgress = {};

bot.start((ctx) => {
    const args = ctx.message.text.split(' ');
    const referrerId = args[1] ? parseInt(args[1]) : null;
    if (!userProgress[ctx.from.id]) {
        userProgress[ctx.from.id] = { step: 1, referrer: referrerId, completed: false };
    }
    if (referrerId && !referrals[referrerId]) referrals[referrerId] = 0;
    ctx.replyWithPhoto({ source: 'HODL.jpg' }, { caption: config.WELCOME_MESSAGE })
        .then(() => sendTask(ctx));
});

function sendTask(ctx) {
    const step = userProgress[ctx.from.id].step;
    if (step === 1) {
        ctx.reply('Task 1: Follow us on Twitter\n' + config.TWITTER_LINK, {
            reply_markup: { inline_keyboard: [[{ text: '✅ Done', callback_data: 'done1' }]] }
        });
    } else if (step === 2) {
        ctx.reply('Task 2: Join our Telegram Channel\n' + config.CHANNEL_LINK, {
            reply_markup: { inline_keyboard: [[{ text: '✅ Done', callback_data: 'done2' }]] }
        });
    } else if (step === 3) {
        ctx.reply('Task 3: Join our Telegram Group\n' + config.GROUP_LINK, {
            reply_markup: { inline_keyboard: [[{ text: '✅ Verify', callback_data: 'verify_group' }]] }
        });
    } else {
        ctx.reply('🎉 All tasks completed!');
    }
}

bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery.data;
    if (data === 'done1') {
        userProgress[ctx.from.id].step = 2;
        sendTask(ctx);
    } else if (data === 'done2') {
        userProgress[ctx.from.id].step = 3;
        sendTask(ctx);
    } else if (data === 'verify_group') {
        try {
            const member = await ctx.telegram.getChatMember(config.GROUP_ID, ctx.from.id);
            if (member && ['member', 'administrator', 'creator'].includes(member.status)) {
                userProgress[ctx.from.id].completed = true;
                ctx.reply('✅ Group join verified! You have completed all tasks.');
                const referrer = userProgress[ctx.from.id].referrer;
                if (referrer) {
                    referrals[referrer] += 1;
                    ctx.telegram.sendMessage(referrer, `🎉 You earned ${config.REWARD_AMOUNT} HODL tokens for referring ${ctx.from.first_name}!`);
                }
            } else {
                ctx.reply('❌ You have not joined the group. Please join and click Verify again.');
            }
        } catch (err) {
            ctx.reply('⚠️ Could not verify group membership.');
        }
    }
    ctx.answerCbQuery();
});

bot.command('stats', (ctx) => {
    const count = referrals[ctx.from.id] || 0;
    const tokens = count * config.REWARD_AMOUNT;
    ctx.reply(`📊 Referrals: ${count}\n💰 Tokens earned: ${tokens}`);
});

bot.launch();
